<@php

namespace {namespace};

use CodeIgniter\Database\Seeder;

class {class} extends Seeder
{
    public function run()
    {
        //
    }
}
